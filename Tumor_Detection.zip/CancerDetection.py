import numpy as np
import cv2
from common import Sketcher
import sys
import cv2
import numpy
from scipy.ndimage import label
def segment_on_dt(a, img):

border = cv2.dilate(img, None, iterations=3)
border = border - cv2.erode(border, None)
cv2.imshow('Result1', border)
dt = cv2.distanceTransform(img, 2, 3)
dt = ((dt - dt.min()) / (dt.max() - dt.min()) *
255).astype(numpy.uint8)
_, dt = cv2.threshold(dt, 236.8, 255, cv2.THRESH_BINARY)
lbl, ncc = label(dt)
lbl = lbl * (255/ncc)
lbl[border == 255] = 255
lbl = lbl.astype(numpy.int32)
cv2.watershed(a, lbl)
lbl[lbl == -1] = 0
lbl = lbl.astype(numpy.uint8)
return 255 - lbl
img = cv2.imread('cancer.png')
cv2.imshow('Input Image', img)
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, img_bin = cv2.threshold(img_gray, 0, 255,
cv2.THRESH_OTSU)
img_bin = cv2.morphologyEx(img_bin, cv2.MORPH_OPEN,
numpy.ones((13, 13), dtype=int))
result = segment_on_dt(img, img_bin)
cv2.imshow('Affected Areas', result)
result[result != 255] = 0
result = cv2.dilate(result, None)
img[result == 255] = (0, 0, 255)
cv2.imshow('Result', img)
class App:
def __init__(self, fn):
self.img = cv2.imread(fn)

def run(self):
while True:
ch = 0xFF & cv2.waitKey(50)
cv2.destroyAllWindows()
if __name__ == '__main__':
import sys
try: fn = sys.argv[1]
except: fn = 'brain.jpg'
print __doc__
App (fn).run ()