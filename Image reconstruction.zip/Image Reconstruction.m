img=imread('image_2.jpg');
img=imresize(img,0.7);
figure(1);
imshow(img);
title('Original Image');
img_ycbcr=rgb2ycbcr(img);
Y=img_ycbcr(:,:,1);
figure(2);
subplot(1, 2, 1);
imshow(img_ycbcr);
title('Y-Cb-Cr Image');
subplot(1, 2, 2);
imshow(Y);
title('Y Component');
BW = im2bw(Y);
B_filtered =medfilt2(BW);
figure(3);
subplot(1, 2, 1);
imshow(BW);
title('Black and White Image');
subplot(1, 2, 2);
imshow(B_filtered);
title('Cleaned-up Image');
% I = im2double(img);
% f = @(x) sqrt(min(x(:)));
% I2 = nlfilter(I,[2 2],f);
% filterSize = [11 11];
% padSize = (filterSize-1)/2;
% img_pad = padarray(img, padSize, 'replicate','both');
% int_img = integralImage(img_pad);
% B_boxfilter = integralBoxFilter(int_img, filterSize);
% figure(4);
% subplot(1, 2, 1);
% imshow(BW);
% title('Original Image');
% subplot(1, 2, 2);
% imshow(B_boxfilter,[]);
% title('Filtered Image')
s = ones(7,7) / 7*7;
img_box = imfilter(B_filtered,s,'conv');
img_box_color=imfilter(img,s,'conv');
%display(img_box);
figure(4);
subplot(2, 2, 1);
imshow(img);
title('Original Image');
subplot(2, 2, 2);
imshow(img_box_color);
title('Convoluted Color Image');
subplot(2, 2, 3);
imshow(img_box);
title('Convoluted Image');
SE = strel('square',7);
BW_dilate = imdilate(B_filtered,SE);
BW_erode = imerode(B_filtered,SE);
BW_majority= bwmorph(B_filtered,'majority');
BW_opening= imopen(B_filtered,SE);
BW_closing= imclose(B_filtered,SE);
figure(5);
subplot(3, 2, 1);
imshow(BW_dilate);
title('Dilated Image');
subplot(3, 2, 2);
imshow(BW_erode);
title('Eroded Image');
subplot(3, 2, 3);
imshow(BW_majority);
title('Majority');
subplot(3, 2, 4);
imshow(BW_opening);
title('Opening');
subplot(3, 2, 5);
imshow(BW_closing);
title('Closing');
% img_dilate = imdilate(img,SE);
% figure(6);imshow(BW_dilate);
% img_DT=-bwdist(B_filtered);
% img_DT_cityblock=bwdist(B_filtered,'cityblock');
% figure(6);
% subplot(1,2,1);
% imshow(img_DT);
% title('Distance Transforms');
% subplot(1,2,2);
% imshow(img_DT_cityblock);
k=0;
BW_CC_1=zeros(size(BW,1));
BW_CC_2=zeros(size(BW,1));
BW_DT_1=(zeros(size(BW,1)));
BW_DT_2=(zeros(size(BW,1)));
for r=1:size(BW,1)
    for s=1:size(BW,2)
        if BW(r,s)~=0 && r>1 && s>1
            BW_DT_1(r,s)=1+min(BW_DT_1(r-1,s), BW_DT_1(r,s-1));
        elseif img(r,s)~=0 && r>1
            BW_DT_1(r,s)=1+min(BW_DT_1(r-1,s));
            elseif img(r,s)~=0 && s>1
            BW_DT_1(r,s)=1+min(BW_DT_1(r,s-1));
        end
    end
end
for r=1:size(BW,1)
    for s=1:size(BW,2)
        if BW_DT_1(r,s)~=0 && s<size(BW,2) && r<size(BW,1)
            BW_DT_2(r,s)=min(BW_DT_1(r,s),1+min(BW_DT_1(r,s+1),BW_DT_1(r+1,s)));
        elseif BW_DT_1(r,s)~=0 && r<size(BW,1)
            BW_DT_2(r,s)=min(BW_DT_1(r,s),1+min(BW_DT_1(r+1,s)));
            elseif BW_DT_1(r,s)~=0 && s<size(BW,2)
            BW_DT_2(r,s)=min(BW_DT_1(r,s),1+min(BW_DT_1(r,s+1)));
        end
    end
end
DT_3= ~bwdist(BW);
frwd=BW.*BW_DT_1;
bkwrd=BW.*BW_DT_2;
figure(6);
subplot(2,2,1);
imshow(BW_DT_1);
title('Forward Pass');
subplot(2,2,2);
imshow(BW_DT_2);
title('Backward Pass');
subplot(2,2,3);
imshow(DT_3);
title('Distance Transform');
for i=2:size(BW,1)
    for j=2:size(BW,2)
        BW_CC_1(i,1)=BW(i,1);
        if BW(i,j)==BW(i,j-1);
            BW_CC_1(i,j)=BW_CC_1(i,j-1);
        elseif BW(i,j)==BW(i-1,j);
            BW_CC_1(i,j)=BW(i-1,j);
        else
            k=k+1;
            BW_CC_1(i,j)=k;
        end
    end
end
for i=2:size(BW,1)-1
    for j=2:size(BW,2)
        BW_CC_2(i,1)=BW_CC_1(i,1);
        if BW_CC_1(i,j)==1;
            BW_CC_2(i,j)=BW_CC_1(i,j);
        elseif BW_CC_1(i,j)>1;
            if BW(i,j)==BW_CC_1(i+1,j);
            BW_CC_2(i,j)=BW_CC_1(i+1,j);
            elseif BW(i,j)==BW(i-1,j);
            BW_CC_2(i,j)=BW_CC_1(i-1,j);
            elseif j<size(BW,2)&&BW_CC_1(i,j)==BW_CC_1(i,j+1);
            BW_CC_2(i,j)=BW_CC_1(i,j)-1;
        else
            BW_CC_2(i,j)=BW_CC_1(i,j);
            end
        end
    end
end
figure(7);
subplot(1,2,1);
imshow(BW_CC_1);
title('First Pass');
subplot(1,2,2);
imshow(BW_CC_2);
title('Connected Components');



