img=imread('landscape1.jpg');
R=img(:,:,1);
G=img(:,:,2);
B=img(:,:,3);
figure(1);
subplot(2, 2, 1);
imshow(img);
subplot(2, 2, 2);
imshow(R);
subplot(2, 2, 3);
imshow(G);
subplot(2, 2, 4);
imshow(B);
img_ycbcr=rgb2ycbcr(img);
Y=img_ycbcr(:,:,1);
cb=img_ycbcr(:,:,2);
cr=img_ycbcr(:,:,3);
figure(2);
subplot(2, 2, 1);
imshow(img_ycbcr);
subplot(2, 2, 2);
imshow(Y);
subplot(2, 2, 3);
imshow(cb);
subplot(2, 2, 4);
imshow(cr);
for i=0:2
    n1=input('enter no of bits to be removed for Y component');
    n2=input('enter no of bits to be removed for cb component');
    n3=input('enter no of bits to be removed for cr component');
    Y_comp=zeros(size(Y));
    Y_comp=uint8(Y_comp);
    for x=1:size(Y,1)
        for y=1:size(Y,2)
            for j=0:2^n1:255-2^n1
                if(Y(x,y)>=j && Y(x,y)<j+(2^n1))
                    Y_comp(x,y)=j;
                end
            end
        end
    end
    cb_comp=zeros(size(cb));
    cb_comp=uint8(cb_comp);
    for x=1:size(cb,1)
        for y=1:size(cb,2)
            for k=0:2^n2:255-2^n2
                if(cb(x,y)>=k && cb(x,y)<k+(2^n2))
                    cb_comp(x,y)=k;
                end
            end
        end
    end
cr_comp=zeros(size(cr));
cr_comp=uint8(cr_comp);
    for x=1:size(cr,1)
        for y=1:size(cr,2)
            for l=0:2^n3:255-2^n3
                if(cr(x,y)>=l && cr(x,y)<l+(2^n3))
                    cr_comp(x,y)=l;
                end
            end
        end
    end
img_comp1_ycbcr=cat(3,Y_comp,cb_comp,cr_comp);
figure(3+i);
subplot(2, 2, 1);
imshow(img_comp1_ycbcr);
subplot(2, 2, 2);
imshow(Y_comp);
subplot(2, 2, 3);
imshow(cb_comp);
subplot(2, 2, 4);
imshow(cr_comp);
img_comp1_rgb=ycbcr2rgb(img_comp1_ycbcr);
figure(4+i);
subplot(1, 2, 1);
imshow(img_comp1_rgb);
subplot(1, 2, 2);
imshow(img_comp1_ycbcr);
psnr_Value = psnr(img_comp1_rgb,img);
display(psnr_Value);
end

